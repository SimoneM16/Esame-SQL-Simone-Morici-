-- Creo le tabelle associate a ciascuna entità/relazione

create table Prodotti                     
(                                         
Product varchar(20),
Product_id varchar(20) unique,
Category varchar(20),
Price float (4,2)                    
);

insert into Prodotti (Product,Product_id,Category,Price) values     
("Risiko","A","Adulti",22),
("Bambola","B","Bambini",19),
("Slime","C","Bambini",3),
("Peluche","D","Neonati",8);

create table Regioni                     
(                                         
Region varchar(20),
Region_id integer unique                    
);

insert into Regioni (Region,Region_id) values     
("Italia",1),
("US",2),
("Giappone",3);

create table Vendite                       
(                                         
Product_id varchar(20),
Quantity integer,
Region_id integer,
Sale_date date,
Sale_id varchar(2) unique                    
);

insert into Vendite (Product_id,Quantity,Region_id,Sale_date,Sale_id) values     
("A",23,1,"2021-01-10","A1"),
("A",40,2,"2023-03-15","A2"),
("A",16,3,"2022-08-09","A3"),
("B",0,1,"2022-05-14","B1"),
("B",25,2,"2023-10-02","B2"),
("B",19,3,"2021-07-01","B3"),
("C",4,1,"2023-08-08","C1"),
("C",6,2,"2022-12-22","C2"),
("C",0,3,"2022-06-26","C3"),
("D",100,1,"2023-07-28","D1"),
("D",60,2,"2021-11-21","D2"),
("D",1,3,"2023-02-16","D3");

-- Esercizio 1
-- Confronto, per ciascun PK di ogni tabella, se i valori totali di quella colonna sono uguali a quelli distinti. 

select count(Product_id) as Valori_totali_id_Prodotti, count(distinct Product_id) as Valori_distinti_id_Prodotti from Prodotti;

select count(Region_id) as Valori_totali_id_Regioni, count(distinct Region_id) as Valori_totali_id_Regioni from Regioni;

select count(Sale_id) as Valori_totali_id_Vendite, count(distinct Sale_id) as Valori_distinti_id_Vendite from Vendite;

-- Esercizio 2

select Product as Prodotto, year(Sale_date) as Anno_vendita, sum(Quantity*Price) as Fatturato 
from Prodotti natural join Vendite 
group by year(Sale_date), Product_id;

-- Esercizio 3

select Region, year(Sale_date) as Anno_vendita, sum(Quantity*Price) as Fatturato 
from Prodotti natural join Regioni natural join Vendite
group by Region, year(Sale_date)
order by sum(Quantity*Price) desc;

-- Esercizio 4

select Category, sum(Quantity) as Vendite_totali 
from Prodotti natural join Vendite
group by Category order by sum(Quantity) desc;

-- Esercizio 5
-- Creo una tabella in cui inserisco le vendite relative a ciascun prodotto, poi seleziono (se ci sono) quei prodotti con zero vendite.
-- Ho usato un unico metodo invece dei due richiesti.

select Product, sum(Quantity) as Vendite_totali 
from Prodotti natural join Vendite 
group by Product;

select Product as Prodotti_invenduti from Zero_vendite where Vendite_totali=0;















